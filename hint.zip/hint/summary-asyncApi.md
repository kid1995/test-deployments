# hint API
## _(asynchron)_

Die asynchrone hint API empfängt über Kafka Hints (Hinweise) und speichert diese in einer mongoDB.