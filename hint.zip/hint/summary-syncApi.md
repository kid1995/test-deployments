# hint API
## _(synchron)_

Die synchrone hint API ermöglicht es, hints (Hinweise) per POST-Request an den hint Service zu schicken.
Zudem können per GET-Request entweder alle Hinweise oder ein konkreter (per ID) abgefragt werden.