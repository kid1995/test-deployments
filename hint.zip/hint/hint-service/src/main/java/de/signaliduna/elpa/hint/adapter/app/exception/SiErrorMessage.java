package de.signaliduna.elpa.hint.adapter.app.exception;

public record SiErrorMessage(String message, String reason) {
}
