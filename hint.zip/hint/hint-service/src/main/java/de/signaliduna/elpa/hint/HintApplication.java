package de.signaliduna.elpa.hint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HintApplication {

	public static void main(String[] args) {
		SpringApplication.run(HintApplication.class, args);
	}

}
