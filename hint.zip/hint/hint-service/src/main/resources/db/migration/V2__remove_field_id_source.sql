alter table hint drop column field_id_source;
