call dbad.stopchange_hint();
