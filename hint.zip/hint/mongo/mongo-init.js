db = db.getSiblingDB('mongodb');

db.createUser(
	{
		user: "mongouser",
		pwd: "mongopass",
		roles: [
			{
				role: "readWrite",
				db: "mongodb"
			}
		]
	}
);
